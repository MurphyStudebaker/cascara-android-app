package com.example.murphy.cascara;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/** @Author Murphy Studebaker
 *
 * This class handles all of the data communication
 * between the networking classes and the ViewModels.
 */
public class CascaraRepository {
    private CoffeeShop[] coffeeShops;
    private CoffeeShop activeCoffeeShop;
    private User activeUser;
    private String filter;
    private int intFilterValue;
    private String stringFilterValue;

    API api;
    Context appContext;
    //RequestQueue que;

    public CascaraRepository(Context context) {
        activeCoffeeShop = null;
        appContext = context;
        activeUser = null;
        filter = null;
        //que = Volley.newRequestQueue(context);
    }

    public CoffeeShop[] getCoffeeShops() {
        return coffeeShops;
    }

    public void setCoffeeShops(CoffeeShop[] coffeeShops) {
        this.coffeeShops = coffeeShops;
    }

    public CoffeeShop getActiveCoffeeShop() {
        return activeCoffeeShop;
    }

    public void setActiveCoffeeShop(CoffeeShop activeCoffeeShop) {
        this.activeCoffeeShop = activeCoffeeShop;
    }

    public User getActiveUser() {
        return activeUser;
    }

    public void setActiveUser(User activeUser) {
        this.activeUser = activeUser;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }

    public int getIntFilterValue() {
        return intFilterValue;
    }

    public void setIntFilterValue(int intFilterValue) {
        this.intFilterValue = intFilterValue;
    }

    public String getStringFilterValue() {
        return stringFilterValue;
    }

    public void setStringFilterValue(String stringFilterValue) {
        this.stringFilterValue = stringFilterValue;
    }
}
