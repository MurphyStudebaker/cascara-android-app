package com.example.murphy.cascara;

import android.app.Application;

public class CascaraApplication extends Application {
    CascaraRepository repo = new CascaraRepository(this);

    public CascaraRepository getRepo() {
        return repo;
    }
}
